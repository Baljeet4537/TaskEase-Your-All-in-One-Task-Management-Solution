import 'package:floor/floor.dart';

@entity
class NoteEntity {
  @PrimaryKey(autoGenerate: true)
  final int? id;
  final String title;
  final String? desc;

  NoteEntity(this.id, this.title, this.desc);
}
