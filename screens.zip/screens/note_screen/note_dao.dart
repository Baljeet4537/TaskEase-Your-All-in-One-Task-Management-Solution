import 'package:floor/floor.dart';
import 'note_model.dart';

@dao
abstract class NoteDao {
  @Query("SELECT * FROM NoteEntity")
  Stream<List<NoteEntity>> getAllNote();

  @Insert()
  Future<int> addNote(NoteEntity note);

  @Query("SELECT * FROM NoteEntity WHERE id = :id")
  Future<NoteEntity?> getNoteById(int id);

  @Query("DELETE FROM NoteEntity WHERE id = :id")
  Future<void> removeNote(int id);
}
