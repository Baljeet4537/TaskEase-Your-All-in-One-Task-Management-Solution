import 'dart:async';

import 'package:floor/floor.dart';
import 'note_dao.dart';
import 'note_model.dart';
import 'package:sqflite/sqflite.dart'as sqflite;

part 'note_database.g.dart';


@Database(version: 1, entities: [NoteEntity])
abstract class NoteDatabase extends FloorDatabase{
  NoteDao get noteDao;
}