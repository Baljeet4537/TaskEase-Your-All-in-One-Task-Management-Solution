import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'note_database.dart';

class Note extends ConsumerStatefulWidget {
  const Note({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() {
    return NoteScreen();
  }
}

class NoteScreen extends ConsumerState<Note> {
  @override
  void initState() {
    super.initState();
    //callDb();
  }
  //
  // Future<void> callDb() async {
  //   try {
  //     final database = await $FloorNoteDatabase.databaseBuilder('notes_database1.db').build();
  //     final dao = database.noteDao;
  //     // Test the database connection
  //     print('Database initialized successfully.');
  //   } catch (e) {
  //     print('Error initializing database: $e');
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "TaskEase",
          style: TextStyle(
            fontSize: 16,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.blueAccent,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Handle adding a new task
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text("Add Task"),
              content: TextField(
                decoration: const InputDecoration(hintText: "Enter task"),
                onSubmitted: (value) {
                  Navigator.pop(context);
                  // Add logic to save task to database
                  print('Task added: $value');
                },
              ),
            ),
          );
        },
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: const Padding(
        padding: EdgeInsets.all(15.0),
        child: Column(
          children: [
            Text("Body content goes here"),
          ],
        ),
      ),
    );
  }
}
